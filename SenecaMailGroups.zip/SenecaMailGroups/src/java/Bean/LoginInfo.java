/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;

/**
 *
 * @author v.leung
 */
public class LoginInfo extends Object implements java.io.Serializable {

    private String name;
    private String empid;
    private String senecaemail;
    private String role;

    public LoginInfo() {
        name = "";
        empid = "";
        senecaemail = "";
        role = "";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid;
    }

    public String getSenecaemail() {
        return senecaemail;
    }

    public void setSenecaemail(String senecaemail) {
        this.senecaemail = senecaemail;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
