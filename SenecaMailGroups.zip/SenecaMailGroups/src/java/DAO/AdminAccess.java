/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Const.Application;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import seneca.database.Database;

/**
 *
 * @author v.leung
 */
public class AdminAccess {

    ArrayList<String> emplid = new ArrayList<String>();
    ArrayList<String> userName = new ArrayList<String>();
    ArrayList<String> wsa_access = new ArrayList<String>();

    seneca.database.Database oDB;
    public String role = "";

    public AdminAccess() {
    }

    public ArrayList<String> getEmplid() {
        return emplid;
    }

    public void setEmplid(ArrayList<String> emplid) {
        this.emplid = emplid;
    }

    public ArrayList<String> getUserName() {
        return userName;
    }

    public void setUserName(ArrayList<String> userName) {
        this.userName = userName;
    }

    public ArrayList<String> getWsa_access() {
        return wsa_access;
    }

    public void setWsa_access(ArrayList<String> wsa_access) {
        this.wsa_access = wsa_access;
    }

    public Database getoDB() {
        return oDB;
    }

    public void setoDB(Database oDB) {
        this.oDB = oDB;
    }

    public String getRole() {
        return role;
    }

    public void getAllRoles() {
        PreparedStatement psSelect = null;
        ResultSet rs = null;
        oDB = new seneca.database.Database();
        WebService.Employee emp = new WebService.Employee();
        try {
            oDB.connect(Application.SOURCE);
            psSelect = oDB.prepareStatement("SELECT WSA_EMP_ID, WSA_ACCESS FROM SENECA.WEB_SECURITY_ACCESS WHERE WSA_APPLICATION = ?");
            psSelect.setString(1, "MAILGROUPS");
            rs = psSelect.executeQuery();
            while (rs.next()) {
                String s = rs.getString(1);
                emplid.add(s);
                String emplid = ("000000000" + s).substring(s.length());
                WebService.Employee ws = new WebService.Employee();
                String temp = ws.getEmployee(emplid).getEmail();
                temp = temp.substring(0, temp.indexOf('@'));
                userName.add(temp);

                temp = rs.getString(2);

                if (temp.equals("I"))
                    temp = "ITS";
                else if (temp.equals("A")) {
                    temp = "Admin";
                } else {
                    temp = "User";
                }
                wsa_access.add(temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
            }
            try {
                psSelect.close();

            } catch (Exception e) {
            }

            try {
                oDB.disconnect();
            } catch (Exception e) {
            }
        }
        String s = "";
    }

    public boolean setRole(String user, String role) {
        WebService.Employee ws = new WebService.Employee();
        ws = ws.getEmployee(user.toUpperCase());

        if (ws == null) {
            return false;
        }
        if (role.equalsIgnoreCase("admin")) {
            role = "A";
        } else {
            role = "U";
        }

        boolean set = false;

        PreparedStatement psInsert = null;
        PreparedStatement psSelect = null;
        PreparedStatement psUpdate = null;

        ResultSet rs = null;
        oDB = new seneca.database.Database();
        boolean inserted = false;
        try {
            oDB.connect(Application.SOURCE);
            psSelect = oDB.prepareStatement("SELECT COUNT(*) FROM SENECA.WEB_SECURITY_ACCESS WHERE WSA_EMP_ID = ? AND WSA_APPLICATION = ?");
            psSelect.setString(1, ws.getEmplid().replaceAll("^0*", ""));
            psSelect.setString(2, "MAILGROUPS");

            rs = psSelect.executeQuery();
            int count = 0;
            if (rs.next()) {
                count = rs.getInt(1);
            }

            if (count == 0) {
                psInsert = oDB.prepareStatement("INSERT INTO SENECA.WEB_SECURITY_ACCESS VALUES (?,?,?)");
                psInsert.setString(1, ws.getEmplid().replaceAll("^0*", ""));
                psInsert.setString(2, "MAILGROUPS");
                psInsert.setString(3, role);
                psInsert.executeQuery();

            } else {
                psUpdate = oDB.prepareStatement("UPDATE SENECA.WEB_SECURITY_ACCESS SET WSA_ACCESS = ? WHERE WSA_EMP_ID = ? AND WSA_APPLICATION = ?");
                psUpdate.setString(1, role);
                psUpdate.setString(2, ws.getEmplid().replaceAll("^0*", ""));
                psUpdate.setString(3, "MAILGROUPS");
                psUpdate.executeQuery();
            }
            oDB.commit();
            set = true;

        } catch (Exception ex) {
            set = false;
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
            }
            try {
                psInsert.close();
                psUpdate.close();
                psSelect.close();

            } catch (Exception e) {
            }

            try {
                oDB.disconnect();
            } catch (Exception e) {
            }
        }

        return set;
    }

    public void retrieveRole(String emplid) {
        //boolean admin = false;
        PreparedStatement psSelect = null;
        ResultSet rs = null;
        oDB = new seneca.database.Database();
        String access = "";
        try {
            if (oDB.connect(Application.SOURCE)) {
                psSelect = oDB.prepareStatement("SELECT WSA_ACCESS FROM SENECA.WEB_SECURITY_ACCESS WHERE WSA_APPLICATION = ? AND WSA_EMP_ID = ?");
                psSelect.setString(1, "MAILGROUPS");
                psSelect.setString(2, emplid.replaceAll("^0*", "")); // remove leading zeros since db is 'number' type
                rs = psSelect.executeQuery();
                if (rs.next()) {
                    access = rs.getString("WSA_ACCESS");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {

            try {
                rs.close();
            } catch (Exception e) {
            }
            try {
                psSelect.close();
            } catch (Exception e) {
            }

            try {
                oDB.disconnect();
            } catch (Exception e) {
            }
        }
        if (access.equalsIgnoreCase("I") || access.equalsIgnoreCase("A") || access.equalsIgnoreCase("U")) {
            role = access;
        }
    }

    public boolean removeUser(String userID) {
        PreparedStatement psInsert = null;
        ResultSet rs = null;

        try {
            oDB = new seneca.database.Database();
            if (oDB.connect(Application.SOURCE)) {
                psInsert = oDB.prepareStatement("DELETE FROM SENECA.WEB_SECURITY_ACCESS WHERE WSA_EMP_ID = ? AND WSA_APPLICATION = ?");
                psInsert.setString(1, userID.replaceAll("^0*", ""));
                psInsert.setString(2, "MAILGROUPS");
                rs = psInsert.executeQuery();
                oDB.commit();
            }
        } catch (Exception e) {
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
            }
            try {
                psInsert.close();
            } catch (Exception e) {
            }

            try {
                oDB.disconnect();
            } catch (Exception e) {
            }
        }
        return true;
    }
}
