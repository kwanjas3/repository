package DAO;

import Const.Application;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.Transformer;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 //https://www.tutorialspoint.com/java_xml/java_dom_parse_document.htm
 //https://www.mkyong.com/java/how-to-modify-xml-file-in-java-dom-parser/
 */
/*
 <email_groups_config>
 ---<email_group>
 ---+++<group_name>group1</group_name>
 ---+++<sender_list>
 ---+++---<group_sender>1</group_sender>
 ---+++---<group_sender>2</group_sender>
 ---+++---<group_sender>...</group_sender>
 ---+++---<group_sender>n</group_sender>
 ---+++</sender_list>
 ---</email_group>
 ---<email_group>
 ---+++<group_name>group2</group_name>
 ---+++<sender_list>
 ---+++---<group_sender>1</group_sender>
 ---+++---<group_sender>2</group_sender>
 ---+++---<group_sender>...</group_sender>
 ---+++---<group_sender>n</group_sender>
 ---+++</sender_list>
 ---</email_group>  
 </email_groups_config> 
 */
/**
 *
 * @author v.leung
 */
public class EmailGroupsConfig {

    private String sError;
    private String sMessage;
    private seneca.database.Database oDB;
    seneca.util.Logger oLogFile = null;

    String xml;

    public EmailGroupsConfig() {
    }

    public String getXML() {
        return xml;
    }

    /**
     * Add the new group as a the last child on the list
     *
     * @param groupName
     * @return
     */
    public boolean addGroup(String groupName, String[] members, String description) {
        boolean updated = false;
        try {

            ArrayList<String> check = getAllGroupNames();
            if (check.contains(groupName)) {
                return updateGroupMembers(groupName, members, "groupSender", true);
            }
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            DocumentBuilder b = f.newDocumentBuilder();
            org.w3c.dom.Document doc = b.parse(new ByteArrayInputStream(xml.getBytes()));
            NodeList groupList = doc.getElementsByTagName("email_groups_config");

            Node n = groupList.item(0);

            Element emailGroup = null;
            emailGroup = doc.createElement("email_group");
            n.appendChild(emailGroup);

            Element newGroupName = doc.createElement("group_name");
            newGroupName.setTextContent(groupName);

            Node n1 = n.getLastChild();
            n1.appendChild(newGroupName);

            Element desc = doc.createElement("description");
            desc.setTextContent(description);
            n1.appendChild(desc);

            Element senderList = doc.createElement("sender_list");
            n1.appendChild(senderList);

            Node n2 = n1.getLastChild();

            for (int i = 0; i < members.length; i++) {
                //   System.out.println("members>" + i + ">" + members[i]);
                Element groupSender = null;
                groupSender = doc.createElement("group_sender");
                groupSender.setTextContent(members[i] + "@senecacollege.ca");
                n2.appendChild(groupSender);
            }

            Element additionalMembers = doc.createElement("additional_members");
            n1.appendChild(additionalMembers);
            clean(n);

            DOMSource source = new DOMSource(doc);
            StringWriter writer = new StringWriter();
            StreamResult result = new StreamResult(writer);
            TransformerFactory tFactory = TransformerFactory.newInstance();
            Transformer transformer = tFactory.newTransformer();

            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "3");

            transformer.transform(source, result);
            String strResult = writer.toString();
            //  System.out.println(">>>after>>>" + strResult);
            updated = true;
            updateXML(strResult);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return updated;

    }

    /**
     * Update description tag's value in the XML for the groupName
     *
     * @param groupName
     * @param description
     * @return true description has been updated
     * @return false description has not been updated
     */
    public boolean updateGroupDescription(String groupName, String description) {
        boolean found = false;
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            DocumentBuilder b = f.newDocumentBuilder();
            org.w3c.dom.Document doc = b.parse(new ByteArrayInputStream(xml.getBytes("UTF-8")));
            NodeList groupList = doc.getElementsByTagName("email_group");
            boolean done = false;
            for (int i = 0; i < groupList.getLength() && !done; i++) {
                NodeList groupNameChild = groupList.item(i).getChildNodes();
                for (int j = 0; j < groupNameChild.getLength() && !done; j++) {
                    Node n = groupNameChild.item(j);

                    if (n.getNodeType() == Node.ELEMENT_NODE && !done) {
                        if (n.getNodeName().equals("group_name") && n.getTextContent().equals(groupName)) {
                            found = true;
                        }

                        if (found && n.getNodeName().equals("description")) {
                            n.setTextContent(description);
                            done = true;
                            break;
                        }
                    }
                }
            }
            DOMSource source = new DOMSource(doc);
            StringWriter writer = new StringWriter();
            StreamResult result = new StreamResult(writer);
            TransformerFactory tFactory = TransformerFactory.newInstance();
            Transformer transformer = tFactory.newTransformer();

            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "3");

            transformer.transform(source, result);
            String strResult = writer.toString();
            this.xml = strResult;

        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * Remove all members under the groupName and then add the members. Harder to check if the element has been removed/added.
     *
     * @param groupName group name to search for
     * @param members new members to add
     * @return
     */
    public boolean updateGroupMembers(String groupName, String[] members, String attributeType, boolean commit) {
        boolean found = false;
        boolean updated = false;
        ArrayList<String> added = new ArrayList<String>();
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            DocumentBuilder b = f.newDocumentBuilder();
            org.w3c.dom.Document doc = b.parse(new ByteArrayInputStream(xml.getBytes()));

            NodeList groupList = doc.getElementsByTagName("email_group");
            for (int i = 0; i < groupList.getLength(); i++) {
                NodeList groupNameChild = groupList.item(i).getChildNodes();

                for (int j = 0; j < groupNameChild.getLength(); j++) {
                    Node n = groupNameChild.item(j);

                    if (n.getNodeType() == Node.ELEMENT_NODE) {
                        //  System.out.println("nodename>" + n.getNodeName());
                        // System.out.println("content>" + n.getTextContent());
                        if (n.getNodeName().equals("group_name") && n.getTextContent().equals(groupName)) {
                            found = true;

                        } // next child node, no point traversing through XML
                        else if (n.getNodeName().equals("group_name") && !n.getTextContent().equals(groupName)) {
                            found = false;
                        }
                        // System.out.println("fnd>" + found);
                        NodeList groupSenders = n.getChildNodes();
                        for (int k = 0; k < groupSenders.getLength() && found; k++) {
                            Node gs = groupSenders.item(k);

                            if (Const.Application.DEBUG) {
                                System.out.println("nodename>" + gs.getNodeName());
                                System.out.println("content>" + gs.getTextContent());
                            }
                            String child = "";
                            if (attributeType.equals("sender_list")) {
                                child = "group_sender";
                            } else if (attributeType.equals("additional_members")) {
                                child = "add_member";
                            }
                            if (gs.getNodeType() == Node.ELEMENT_NODE && gs.getNodeName().equals(child)) {
                                //   System.out.println(">" + gs.getTextContent());
                                n.removeChild(gs);
                                //  System.out.println("removed>" + k + ">" + gs.getTextContent());
                            }
                        }
                    }
                }
            }

            found = false;
            updated = false;
            boolean finished = false;
            System.out.println("members.length>" + members.length);
            for (int i = 0; i < groupList.getLength() & !finished; i++) {
                NodeList groupNameChild = groupList.item(i).getChildNodes();
                for (int j = 0; j < groupNameChild.getLength() & !finished; j++) {
                    Node n = groupNameChild.item(j);

                    if (n.getNodeType() == Node.ELEMENT_NODE) {
                        if (Const.Application.DEBUG) {
                            System.out.println("nodename>" + n.getNodeName());
                            System.out.println("content>" + n.getTextContent());
                        }
                        if (n.getNodeName().equals("group_name") && n.getTextContent().equals(groupName)) {
                            found = true;
                            //System.out.println("bb>" + n.getNextSibling().getNodeName());

                            if (Const.Application.DEBUG) {
                                Node z = n.cloneNode(true);
                                while ((z = z.getNextSibling()) != null) {
                                    System.out.println(">>>>>" + z.getNodeName());
                                    if (z.getNodeType() == Node.ELEMENT_NODE) {
                                        if (z.getNodeName().equals("attributeType")) {
                                            System.out.println("found it!!!");
                                        }
                                    }
                                }
                            }
                        }

                        if (found && n.getNodeName().equals(attributeType)) {
                            Element groupSender = null;
                            for (int z = 0; z < members.length && found; z++) {
                                if (members[z].trim().length() > 0 && !added.contains(members[z])) {
                                    added.add(members[z]);
                                }
                                if (attributeType.equals("sender_list")) {
                                    groupSender = doc.createElement("group_sender");
                                } else if (attributeType.equals("additional_members")) {
                                    groupSender = doc.createElement("add_member");
                                }

                                if (members[z].trim().length() > 0) {
                                    groupSender.setTextContent(members[z] + "@senecacollege.ca");
                                    n.appendChild(groupSender);
                                }
                            }
                            finished = true;
                        }
                    }
                    clean(n);
                }
            }

            DOMSource source = new DOMSource(doc);
            StringWriter writer = new StringWriter();
            StreamResult result = new StreamResult(writer);
            TransformerFactory tFactory = TransformerFactory.newInstance();
            Transformer transformer = tFactory.newTransformer();

            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "3");

            transformer.transform(source, result);
            String strResult = writer.toString();
            updated = true;
            if (commit) {
                updateXML(strResult);
            }
            this.xml = strResult;
        } catch (Exception e) {
            e.printStackTrace();
            updated = false;
        }

        return updated;
    }

    public boolean updateXML(String xml) {
        boolean updated = false;
        PreparedStatement psUpdate = null;
        ResultSet rs = null;
        oDB = new seneca.database.Database();

        try {
            oDB.connect(Application.SOURCE);
            psUpdate = oDB.prepareStatement("UPDATE MISC_XML"
                    + " SET MX_RECORD_TIMESTAMP = TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') || '00000' "
                    + " , MX_DATA = ?"
                    + " WHERE MX_APPLICATION = ? AND MX_TYPE = 'CONF' AND MX_SYSTEM_CODE = '1'"
            );
            StringReader clob = null;
            clob = new StringReader(xml);

            psUpdate.setCharacterStream(1, clob);
            psUpdate.setString(2, "SENECA_MAIL_GROUPS");
            rs = psUpdate.executeQuery();
            rs.next();
            oDB.commit();
            updated = true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
            }
            try {
                psUpdate.close();
            } catch (Exception e) {
            }

            try {
                oDB.commit();

                oDB.disconnect();
            } catch (Exception e) {
            }
        }
        return updated;
    }

    /**
     * Get the description value for the given groupName
     *
     * @param groupName
     * @return String containing the group description
     */
    public String getGroupDescription(String groupName) {
        boolean found = false;
        boolean done = false;
        String description = "";
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            DocumentBuilder b = f.newDocumentBuilder();
            org.w3c.dom.Document doc = b.parse(new ByteArrayInputStream(xml.getBytes("UTF-8")));
            NodeList groupList = doc.getElementsByTagName("email_group");
            for (int i = 0; i < groupList.getLength() && !done; i++) {
                NodeList groupNameChild = groupList.item(i).getChildNodes();
                for (int j = 0; j < groupNameChild.getLength() && !done; j++) {
                    Node n = groupNameChild.item(j);

                    if (n.getNodeType() == Node.ELEMENT_NODE && !done) {
                        if (n.getNodeName().equals("group_name") && n.getTextContent().equals(groupName)) {
                            found = true;
                        }

                        if (found && n.getNodeName().equals("description") && !done) {
                            description = n.getTextContent().trim();
                            done = true;
                        }
                    }
                }
            }
        } catch (Exception e) {
        }

        return description;
    }

    /**
     * Get all group members under the group name
     *
     * @param groupName
     * @return
     */
    public ArrayList<String> getGroupMembers(String groupName, String attributeType) {

        ArrayList<String> out = new ArrayList<String>();
        boolean found = false;
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            DocumentBuilder b = f.newDocumentBuilder();
            org.w3c.dom.Document doc = b.parse(new ByteArrayInputStream(xml.getBytes("UTF-8")));
            NodeList groupList = doc.getElementsByTagName("email_group");
            for (int i = 0; i < groupList.getLength(); i++) {
                NodeList groupNameChild = groupList.item(i).getChildNodes();

                for (int j = 0; j < groupNameChild.getLength(); j++) {
                    Node n = groupNameChild.item(j);

                    if (n.getNodeType() == Node.ELEMENT_NODE) {
                        if (n.getNodeName().equals("group_name") && n.getTextContent().equals(groupName)) {
                            found = true;
                        } // next child node, no point traversing through XML
                        else if (n.getNodeName().equals("group_name") && !n.getTextContent().equals(groupName)) {
                            found = false;
                        }

                        NodeList groupSenders = n.getChildNodes();
                        for (int k = 0; k < groupSenders.getLength() && found; k++) {
                            Node gs = groupSenders.item(k);
                            if (gs.getNodeType() == Node.ELEMENT_NODE && gs.getNodeName().equals(attributeType)) {
                                //System.out.println(">goonda>>" + gs.getNodeName());
                                out.add(gs.getTextContent().substring(0, gs.getTextContent().indexOf("@senecacollege.ca")));
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
        }
        return out;
    }

    public ArrayList<String> getAllGroupNames() {
        ArrayList<String> out = new ArrayList<String>();
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            f.setValidating(false);
            f.setIgnoringComments(true);
            DocumentBuilder b = f.newDocumentBuilder();
            org.w3c.dom.Document doc = b.parse(new ByteArrayInputStream(xml.getBytes("UTF-8")));
            NodeList loop = doc.getElementsByTagName("group_name");
            for (int i = 0; i < loop.getLength(); i++) {
                Node nNode = loop.item(i);
                if (nNode.getNodeName().equals("group_name")) {
                    //  System.out.println("curr element: " + nNode.getTextContent());
                    out.add(nNode.getTextContent());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Collections.sort(out);
        return out;
    }

    /**
     * only return 1 - email_group 2 - group_name
     *
     * <email_groups_config>
     * ---<email_group>
     * ------<group_name>Seneca.Staff.parttime</group_name>
     * ---------<group_sender>person1@senecacollege.ca</group_sender>
     * ---------<group_sender>person2@senecacollege.ca</group_sender>
     * ---</email_group>
     * ---<email_group>
     * ------<group_name>Seneca.Staff.parttime.union</group_name>
     * ---------<group_sender>person3@senecacollege.ca</group_sender>
     * ---------<group_sender>person4@senecacollege.ca</group_sender>
     * ---</email_group>
     * </email_groups_config>
     *
     * @return
     */
    public String getCleanXML() {
        // remove additional_members attributes
        String strResult = "";
        int objectID = 0;
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            DocumentBuilder b = f.newDocumentBuilder();
            org.w3c.dom.Document doc = b.parse(new ByteArrayInputStream(xml.getBytes()));

            NodeList groupList = doc.getElementsByTagName("email_group");
            for (int i = 0; i < groupList.getLength(); i++) {
                NodeList groupNameChild = groupList.item(i).getChildNodes();
                boolean afterNode = false;
                Node z = groupList.item(i);
                String name = "";
                boolean groupSenderCheck = false;
                for (int j = 0; j < groupNameChild.getLength(); j++) {

                    Node n = groupNameChild.item(j);

                    // check the group_name for instances of
                    // category : [Admin, Support, Faculty]
                    // type: [parttime = 'PT', fulltime = 'FT']
                    // campus: [NH, MK, SY]
                    if (n.getNodeName().equals("group_name")) {
                        afterNode = true;
                        // System.out.println("objectID> " + objectID + ", " + n.getTextContent());
                        name = n.getTextContent().toLowerCase();
                    }

                    if (n.getNodeName().equals("sender_list")) {
                        groupSenderCheck = true;
                    }
                    NodeList groupSenders = n.getChildNodes();
                    boolean done = false;
                    int childNode = 0;
                    for (int k = 0; k < groupSenders.getLength(); k++) {
                        Node gs = groupSenders.item(k);
                        if (gs.getNodeType() == Node.ELEMENT_NODE) {
                            childNode++;
                            if (gs.getTextContent().contains("@senecacollege.ca")) {
                                gs.setTextContent(gs.getTextContent().substring(0, gs.getTextContent().indexOf("@")));
                            }
                        }

                        if (k == groupSenders.getLength() - 1 && childNode == 1 && groupSenderCheck && !done) {
                            Element e = null;
                            e = doc.createElement("group_sender");
                            e.setTextContent("");
                            n.appendChild(e);
                            groupSenderCheck = false;
                            done = true;
                        }
                    }
                }
                if (afterNode) {
                    Element e = null;
                    e = doc.createElement("objectID");
                    e.setTextContent(String.valueOf(objectID));
                    z.appendChild(e);

                    objectID++;

                    /**
                     * Category = [Admin, Faculty, Staff]
                     */
                    e = null;
                    e = doc.createElement("category");
                    if (name.contains("admin") || name.contains("manager")
                            || name.contains("director") || name.contains("chair") || name.contains("dean")) {
                        e.setTextContent("Admin");
                    } else if (name.contains("faculty")) {
                        e.setTextContent("Faculty");
                    } else if (name.contains("staff")) {
                        e.setTextContent("Staff");
                    } else {
                        e.setTextContent("");
                    }
                    z.appendChild(e);

                    /**
                     * Type = [PT, PTU, FT, FTU]
                     */
                    e = null;
                    e = doc.createElement("type");
                    if (name.contains("parttime")) {
                        // this list might have both staff and students.  we only care about staff
                        if (!name.contains("student")) {
                            if (name.contains("nonunion")) {
                                e.setTextContent("PTNU");
                            } else if (name.contains("union")) { //partial string match, so we put this as 2nd condition
                                e.setTextContent("PTU");
                            } else {
                                e.setTextContent("PT");
                            }
                        }
                    } else if (name.contains("fulltime")) {
                        if (!name.contains("student")) {
                            if (name.contains("nonunion")) {
                                e.setTextContent("FT");
                            } else if (name.contains("union")) {
                                e.setTextContent("FTU");
                            } else {
                                e.setTextContent("FT");
                            }
                        }
                    } else if (name.contains("partialload")) {
                        e.setTextContent("PL");
                    } else {
                        e.setTextContent("");
                    }
                    z.appendChild(e);

                    /**
                     * Campus = =[YQP, JN, MK, NH, SY, KG]
                     */
                    e = null;
                    e = doc.createElement("campus");

                    if (name.contains(".ypq")) {
                        e.setTextContent("YPQ");
                    } else if (name.contains(".jn")) {
                        e.setTextContent("JN");
                    } else if (name.contains(".mk")) {
                        e.setTextContent("MK");
                    } else if (name.contains(".nh")) {
                        e.setTextContent("NH");
                    } else if (name.contains(".sy")) {
                        e.setTextContent("SY");
                    } else if (name.contains(".kg")) {
                        e.setTextContent("KG");
                    } else if (name.contains(".jn")) {
                        e.setTextContent("JN");
                    } else if (name.contains(".yg")) {
                        e.setTextContent("YG");
                    } else {
                        e.setTextContent("");
                    }
                    z.appendChild(e);

                }
            }

            ////build new XML//////////////////
            DOMSource source = new DOMSource(doc);
            StringWriter writer = new StringWriter();
            StreamResult result = new StreamResult(writer);
            TransformerFactory tFactory = TransformerFactory.newInstance();
            Transformer transformer = tFactory.newTransformer();

            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "3");

            transformer.transform(source, result);
            strResult = writer.toString();

        } catch (Exception e) {
        }
        return strResult;
    }

    public void setLocalXML(String xml) {
        this.xml = xml;
    }

    /**
     * Retrieve the column MX_DATA from MISC_XML
     */
    public void setXML() {
        PreparedStatement psSelect = null;
        ResultSet rs = null;
        oDB = new seneca.database.Database();

        try {
            oDB.connect(Application.SOURCE);
            psSelect = oDB.prepareStatement("SELECT MX_DATA FROM SENECA.MISC_XML WHERE MX_APPLICATION = ?");
            psSelect.setString(1, Application.MX_APPLICATION);

            rs = psSelect.executeQuery();
            if (rs.next()) {
                xml = rs.getString("MX_DATA");
            }
        } catch (Exception ex) {
            // ex.printStackTrace();
            oLogFile.writeLog(ex.toString(), " XML_Transf: getXML");
            sError = "1";
            sMessage = "System error(np-3). Please contact Help Desk.";
        } finally {

            try {
                rs.close();
            } catch (Exception e) {
            }
            try {
                psSelect.close();
            } catch (Exception e) {
            }

            try {
                oDB.disconnect();
            } catch (Exception e) {
            }
        }
    }

    public static String trim(String input) {
        BufferedReader reader = new BufferedReader(new StringReader(input));
        StringBuffer result = new StringBuffer();
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line.trim());
            }
            return result.toString();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //https://stackoverflow.com/questions/978810/how-to-strip-whitespace-only-text-nodes-from-a-dom-before-serialization
    public static void clean(Node node) {
        NodeList childNodes = node.getChildNodes();

        for (int n = childNodes.getLength() - 1; n >= 0; n--) {
            Node child = childNodes.item(n);
            short nodeType = child.getNodeType();

            if (nodeType == Node.ELEMENT_NODE) {
                clean(child);
            } else if (nodeType == Node.TEXT_NODE) {
                String trimmedNodeVal = child.getNodeValue().trim();
                if (trimmedNodeVal.length() == 0) {
                    node.removeChild(child);
                } else {
                    child.setNodeValue(trimmedNodeVal);
                }
            } else if (nodeType == Node.COMMENT_NODE) {
                node.removeChild(child);
            }
        }
    }
}
