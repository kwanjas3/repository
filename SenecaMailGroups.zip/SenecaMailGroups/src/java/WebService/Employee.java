/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebService;

import ca.senecacollege.QueryAccessServiceResponse;
import java.util.logging.Logger;

/**
 *
 * @author v.leung
 */
public class Employee {

    String emplid;
    String firstName;
    String lastName;
    String email;
    String sError;

    public String getsError() {
        return sError;
    }

    public void setsError(String sError) {
        this.sError = sError;
    }

    public String getsMessage() {
        return sMessage;
    }

    public void setsMessage(String sMessage) {
        this.sMessage = sMessage;
    }
    String sMessage;
    seneca.util.Logger oLogFile = null;

    public String getEmplid() {
        return emplid;
    }

    public void setEmplid(String emplid) {
        this.emplid = emplid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Employee() {
        email = "";
        firstName = "";
        lastName = "";
        email = "";
    }

    public Employee getEmployee(String emplid) {
        Employee e = null;

        try {
            /* ca.senecacollege.QueryAccessServiceRequest queryAccessServiceRequest = new ca.senecacollege.QueryAccessServiceRequest();
             queryAccessServiceRequest.setTargetInstance(Const.Application.HR);
             queryAccessServiceRequest.setQueryName(Const.Application.EMPLOYEEQUERY);
             ca.senecacollege.QueryAccessServiceRequest.ParameterList wsRequestParameters = new ca.senecacollege.QueryAccessServiceRequest.ParameterList();
             java.util.List<String> wsRequestParametersItems = wsRequestParameters.getParameterListItem();
             wsRequestParametersItems.add(emplid);
             queryAccessServiceRequest.setParameterList(wsRequestParameters);

             ca.senecacollege.QueryAccessServiceResponse responseWS = executeQueryAccessService(queryAccessServiceRequest);

            
             int itemCtr = 0;
             int itemMax = responseWS.getItems().getItem().size();

             if (itemMax == 0) {
             sError = "1";
             sMessage = "HR webservice: No data found for employee " + emplid;
             oLogFile.writeLog("", "HR webservice: No data found for employee == " + emplid);
             } else {
             e = new Employee();
             e.setEmplid(responseWS.getItems().getItem().get(itemCtr).getItemValue().get(0));
             e.setFirstName(responseWS.getItems().getItem().get(itemCtr).getItemValue().get(1));
             e.setLastName(responseWS.getItems().getItem().get(itemCtr).getItemValue().get(2));
             e.setEmail(responseWS.getItems().getItem().get(itemCtr).getItemValue().get(3));
             }*/
        } catch (Exception ex) {
            ex.printStackTrace();
            oLogFile.writeLog(ex.toString(), "; getEmplDataMain; username == " + emplid);

        } finally {
            if (e == null) {
                e = new Employee();
                e.setEmplid("076210103");
                e.setEmail("vincent.leung@senecacollege.ca");
            }
        }
        return e;
    }

    private static QueryAccessServiceResponse executeQueryAccessService(ca.senecacollege.QueryAccessServiceRequest queryAccessServiceRequest) {
        ca.senecacollege.ExecuteQueryAccessServiceBindingQSService service = new ca.senecacollege.ExecuteQueryAccessServiceBindingQSService();
        ca.senecacollege.ExecuteQueryAccessService port = service.getExecuteQueryAccessServiceBindingQSPort();
        return port.executeQueryAccessService(queryAccessServiceRequest);
    }
    private static final Logger LOG = Logger.getLogger(Employee.class.getName());

}
