/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author v.leung
 */
@WebServlet(name = "UpdateGroupList", urlPatterns = {"/UpdateGroupList"})
public class UpdateGroupList extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        String s = "";
        RequestDispatcher rd = null;
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            if (request.getParameter("setAccess") != null) {
                String success = "";
                String fail = "";
                for (int i = 0; i < 5; i++) {
                    if (request.getParameter("id_" + i) == null || request.getParameter("id_" + i).trim().isEmpty()) {
                    } else {
                        DAO.AdminAccess aa = new DAO.AdminAccess();
                        if (aa.setRole(request.getParameter("id_" + i), request.getParameter("role_" + i))) {
                            success += request.getParameter("id_" + i) + ", ";

                        } else {
                            fail += request.getParameter("id_" + i) + ", ";
                        }
                    }
                }

                if (success.length() > 0) {
                    success = success.substring(0, success.lastIndexOf(','));
                }

                if (fail.length() > 0) {
                    fail = fail.substring(0, fail.lastIndexOf(','));
                }

                request.setAttribute("role", request.getParameter("role"));
                request.setAttribute("success", success);
                request.setAttribute("fail", fail);

                rd = getServletContext().getRequestDispatcher("/Add.jsp");

            } else if (request.getParameter("remAccess") != null) {
                String removed = "";
                if (request.getParameter("ids") != null) {
                    String[] removeID = request.getParameterValues("ids");
                    DAO.AdminAccess r = new DAO.AdminAccess();
                    for (int i = 0; i < removeID.length; i++) {
                        if (r.removeUser(removeID[i])) {
                            WebService.Employee ws = new WebService.Employee();
                            // String emplid = ("000000000" + s).substring(s.length());
                            String emplid = ("000000000" + removeID[i]).substring(removeID[i].length());
                            WebService.Employee employee = new WebService.Employee();
                            employee = employee.getEmployee(emplid);
                            removed += employee.getFirstName() + " " + employee.getLastName() + ", ";
                        }
                    }
                }
                if (removed.length() > 0) {
                    removed = removed.substring(0, removed.lastIndexOf(','));
                }
                request.setAttribute("role", request.getParameter("role"));
                request.setAttribute("removed", removed);
                rd = getServletContext().getRequestDispatcher("/Remove.jsp");

            } else if (request.getParameterValues("groupList") != null && !request.getParameterValues("groupList")[0].equals("empty")
                    && request.getParameterValues("AddMembers") == null) {
                s = request.getParameterValues("groupList")[0].trim();
                request.setAttribute("groupList", s);
                rd = getServletContext().getRequestDispatcher("/UpdateGroupListMembers.jsp");
                //  rd.forward(request, response);
            } else if ((request.getParameterValues("groupList") != null || request.getParameterValues("additionalMembers") != null) && (request.getParameterValues("AddMembers") != null) || request.getParameterValues("AdditionalMembers") != null) {
                // send to EmailGroupsConfig to add new group members

                if (request.getParameterValues("groupList") != null) {
                    s = request.getParameterValues("groupList")[0].trim();
                } else if (request.getParameterValues("additionalMembers") != null) {
                    s = request.getParameterValues("additionalMembers")[0].trim();
                }

                System.out.println("s>" + s);

                request.setAttribute("groupList", s);

                String attr = "";
                String members[] = null;

                String sendersList[] = null;
                String additionalMembers[] = null;
                // sender_list
                if (request.getParameterValues("AddMembers") != null) {
                    //if (request.getParameterValues("Add")[0].toString().equals("Update")) {
                    if (Const.Application.DEBUG) {
                        System.out.println("group_sender to be updated");
                    }
                    //attr = "sender_list";
                    sendersList = request.getParameterValues("AddMembers")[0].split("\\r?\\n");
                    //}
                    //if (request.getParameterValues("AddMembers2")[0].toString().equals("UPDATE")) {
                    if (Const.Application.DEBUG) {
                        System.out.println("add_member to be updated");
                    }
                    //  attr = "additional_members";
                    additionalMembers = request.getParameterValues("AdditionalMembers")[0].split("\\r?\\n");
                    //}
                } // add_member
                // else if (request.getParameterValues("AddMembers2") != null) {

        //        System.out.println(">0>" + attr);

                if (Const.Application.DEBUG) {
                    for (int i = 0; i < sendersList.length; i++) {
                        System.out.println("i=" + i + ", " + sendersList[i]);
                    }
                }

                if (Const.Application.DEBUG) {
                    for (int i = 0; i < additionalMembers.length; i++) {
                        System.out.println("i=" + i + ", " + additionalMembers[i]);
                    }
                }

                DAO.EmailGroupsConfig e = new DAO.EmailGroupsConfig();
                e.setXML();

                System.out.println(request.getParameterValues(""));
                String status = "";
                if (e.updateGroupDescription(s, request.getParameter("description"))) {
                 //   status += "description updated"
                }
                 
                request.setAttribute("description", request.getParameter("description"));
                
                if (e.updateGroupMembers(s, sendersList, "sender_list", false)) {
                    status += "sender list updated";
                    //   request.setAttribute("status", "sender list updated");
                } else {
                    status += "sender update failed";
                    //     request.setAttribute("status", "sender list update failed");
                }

                //   e.setXML();
                if (e.updateGroupMembers(s, additionalMembers, "additional_members", true)) {
                    status += "\nadditional members list updated";
                    //   request.setAttribute("status", "additional members updated");
                } else {
                    status += "\nadditional members list failed";
                }
                request.setAttribute("status", status);

                if (request.getParameterValues("groupList") != null) {
                    request.setAttribute("groupList", request.getParameterValues("groupList")[0].trim());
                } else {
                    request.setAttribute("groupList", request.getParameterValues("additionalMembers")[0].trim());

                }
                rd = getServletContext().getRequestDispatcher("/UpdateGroupListMembers.jsp");
                //rd.forward(request, response);
            } else if (request.getParameterValues("groupList")[0].equals("empty")) {
                rd = getServletContext().getRequestDispatcher("/CallLogin");

            }

            rd.forward(request, response);
        }
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    private static final Logger LOG = Logger.getLogger(UpdateGroupList.class.getName());

}
