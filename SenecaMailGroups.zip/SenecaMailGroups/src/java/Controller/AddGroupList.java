/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author v.leung
 */
@WebServlet(name = "AddGroupList", urlPatterns = {"/AddGroupList"})
public class AddGroupList extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        String s = "";
        RequestDispatcher rd = null;
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            if (request.getParameter("AddMembers") != null) {
                // System.out.println("found new members");
                String members[] = request.getParameterValues("AddMembers")[0].split("\\r?\\n");
                String groupList = request.getParameter("groupList");
                String desc = request.getParameter("description");
                //  System.out.println("members>");
                //    String string = members[i];
                //    System.out.println(i + ">" + string);
                DAO.EmailGroupsConfig e = new DAO.EmailGroupsConfig();
                e.setXML();

                String status = "";
                if (e.addGroup(groupList, members, desc)) {
                    //      System.out.println("new menbers updated");
                    request.setAttribute("status", "list created and members added");
                } else {
                    //  System.out.println("update failed");
                    request.setAttribute("status", "group not added");
                }

                request.setAttribute("groupList", groupList);
                rd = getServletContext().getRequestDispatcher("/UpdateGroupListMembers.jsp");
                rd.forward(request, response);
            }
            if (request.getParameter("addGroupList") != null) {
                s = request.getParameterValues("addGroupList")[0];
                //    System.out.println("addGroupList");
                request.setAttribute("groupList", s);
                rd = getServletContext().getRequestDispatcher("/AddMembers.jsp");
                rd.forward(request, response);
            }
        }
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
