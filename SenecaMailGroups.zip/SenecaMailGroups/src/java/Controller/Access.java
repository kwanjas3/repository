/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author v.leung
 */
public class Access extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String sError = "0";
        String sMessage = "";
        HttpSession session = request.getSession(true);
        String sLogFilePath = "SenecaMailGroups.log";
        response.setContentType("text/html;charset=UTF-8");
        if (session == null) {
            try {
                request.setAttribute("sMessage", "Your session is expired.");
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/Exit_Message.jsp");
                rd.forward(request, response);
            } catch (Exception ex) {
                ;
            }
        } else {
            String username = request.getHeader("ps_sso_uid");

            if (username == null) {
                if (request.getParameterValues("id") != null) {
                    username = request.getParameterValues("id")[0];
                }
            }

            if (request.getParameter("ITSpecialOption") != null) {
                username = request.getParameterValues("ITSpecialOption")[0];
            }

            if (username == null || username.isEmpty()) {
                try {
                    request.setAttribute("sMessage", "No access");
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/Exit_Message.jsp");
                    rd.forward(request, response);
                } catch (Exception ex) {
                    ;
                }
            } else {
                String emplid = "";
                String firstName = "";
                String lastName = "";
                String email = "";

                seneca.util.Logger oLogFile = null;
                oLogFile = new seneca.util.Logger("SenecaMailGroups.log");
                oLogFile.writeLog("", "Access: username.toUpperCase(): " + username.toUpperCase());
                WebService.Employee ws = new WebService.Employee();
                ws = ws.getEmployee(username.toUpperCase());
                if (ws.getEmplid() != null) {

                    emplid = ws.getEmplid();
                    firstName = ws.getFirstName();
                    lastName = ws.getLastName();
                    email = ws.getEmail();

                    DAO.AdminAccess access = new DAO.AdminAccess();
                    access.retrieveRole(emplid);

                    if (access.getRole().equalsIgnoreCase("A") || access.getRole().equalsIgnoreCase("I")) {

                        if (request.getParameter("action") != null) {
                            String fwd = "";
                            if (request.getParameterValues("action")[0].equals("add")) {
                                fwd = "/Add.jsp";
                            } else if (request.getParameterValues("action")[0].equals("remove")) {
                                fwd = "/Remove.jsp";

                            }

                            request.setAttribute("role", access.getRole());
                            RequestDispatcher rd = getServletContext().getRequestDispatcher(fwd);
                            rd.forward(request, response);

                        }
                        RequestDispatcher rd = getServletContext().getRequestDispatcher("/start.jsp");
                    }

                }
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
