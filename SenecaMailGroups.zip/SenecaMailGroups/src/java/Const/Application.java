package Const;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author v.leung
 */
public class Application {
    public static final String MX_APPLICATION = "SENECA_MAIL_GROUPS";
    public static final String EMPLOYEEQUERY = "S3_EMPLOYEE_WS";
    public static final String SOURCE = "seneca_mail_groups";
    public static final String HR = "HRSUP";
    public static final String version = "1.01";
    public static final boolean DEBUG = false;
    
}